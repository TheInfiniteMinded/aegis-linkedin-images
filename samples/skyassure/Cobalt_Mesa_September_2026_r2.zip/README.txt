Aegis SkyAssure evidence bundle: September 2026 BVLOS operations, CMA-BVLOS-26-01
Prepared for Cobalt Mesa Aerial Inspection (fictional)
Package …770c5c60, revision 2
Package hash sha256:7eb5f1b67381cad11d37b6ab26f535612a3409b20736e3dff39a053467d43b4d

Prepared for Cobalt Mesa Aerial Inspection (fictional). Contains proprietary methodology of Aegis Technologies Inc.; licensed for the recipient's internal use only. Not to be reproduced, shared outside the recipient's organisation, used to train or prompt AI systems, or used to develop competing products.

This package records how configured requirements were evaluated against the evidence available to Aegis SkyAssure, and the decisions people in the organization recorded. It is not a determination of legal or regulatory compliance, which remains the responsibility of the operator and the relevant authority.

Contents
  report.html     The evidence report: for every flight and requirement, what was required, what your
                  records show (by your own record ids) and the outcome. Open it in any browser.
  package.json    The same results as data, with the records, findings and reviewer decisions.
  evidence/       Original files attached to your records: a folder per record (your record id), each file
                  named by its SHA-256.
  custody/        Custody records for aircraft, media and parts held for these flights: every handover,
                  by name and place, with the hash of each signed event on the platform.
  SHA256SUMS      The SHA-256 of every file above.
  MANIFEST.json   The same list, signed by Aegis Technologies Inc. (signing key ed25519:f77d9e7c57258d9c).

Checking the files
  Every file's SHA-256 is listed in SHA256SUMS. Check them with any SHA-256 tool, for example:
    sha256sum -c SHA256SUMS           (Linux)
    shasum -a 256 -c SHA256SUMS       (macOS)
    certutil -hashfile <file> SHA256  (Windows, one file at a time)

  On request, Aegis confirms the signature and that this package matches the sealed record it
  holds, and re-checks every result. Ask your Aegis contact.
