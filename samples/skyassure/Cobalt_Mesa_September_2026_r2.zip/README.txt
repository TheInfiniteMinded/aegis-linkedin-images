Aegis SkyAssure evidence bundle: September 2026 BVLOS operations, CMA-BVLOS-26-01
Prepared for Cobalt Mesa Aerial Inspection (fictional)
Package 01a11d2f-7d21-7f08-91e1-da05859afa4b, revision 2
Package hash sha256:f15ccf0451706bd0a072d3c0b14f883368fa5621981d4a58a12fdc0ec0618f9c

Prepared for Cobalt Mesa Aerial Inspection (fictional). Contains proprietary methodology of Aegis Technologies Inc.; licensed for the recipient's internal use only. Not to be reproduced, shared outside the recipient's organisation, used to train or prompt AI systems, or used to develop competing products.

This package records how configured requirements were evaluated against the evidence available to Aegis SkyAssure, and the decisions people in the organization recorded. It is not a determination of legal or regulatory compliance, which remains the responsibility of the operator and the relevant authority.

Contents
  report.html     The evidence report: for every flight and requirement, what was required, what your
                  records show (by your own record ids) and the outcome. Open it in any browser.
  package.json    The same results as data, with the records, findings and reviewer decisions.
  evidence/       Original files attached to your records, named by SHA-256.
  custody/        Signed custody records for aircraft, media and parts held for these flights.
  SHA256SUMS      The SHA-256 of every file above.
  MANIFEST.json   The same list, signed by Aegis Technologies Inc. (signing key ed25519:1c8fefa2a5154f2f).

Checking the files
  Every file's SHA-256 is listed in SHA256SUMS. Check them with any SHA-256 tool, for example:
    sha256sum -c SHA256SUMS           (Linux)
    shasum -a 256 -c SHA256SUMS       (macOS)
    certutil -hashfile <file> SHA256  (Windows, one file at a time)

  On request, Aegis confirms the signature and that this package matches the sealed record it
  holds, and re-checks every result. Ask your Aegis contact.
